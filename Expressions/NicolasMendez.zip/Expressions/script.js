let primero = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.com$/gm;
let segundo = /^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{4}$/;
let tercero = /^[A-Za-z_$][A-Za-z0-9_$]*$/;
let cuarto = /([#@]\w+)/;
let quinto = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;
